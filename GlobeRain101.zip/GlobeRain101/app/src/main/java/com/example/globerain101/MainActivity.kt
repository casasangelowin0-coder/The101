package com.example.globerain101

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    private val routerUrl = "http://192.168.0.1"
    private val dashboardUrl = "http://192.168.0.1/dashboard/"
    private lateinit var routerWeb: WebView
    private lateinit var dashWeb: WebView
    private var onDash = false
    private val web: WebView get() = if (onDash) dashWeb else routerWeb

    private val prefs by lazy {
        val key = MasterKey.Builder(this).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(
            this, "router_login", key,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    // Called from the page's JavaScript when you press Login
    inner class Bridge {
        @JavascriptInterface
        fun save(user: String, pass: String) {
            if (pass.isBlank()) return
            if (prefs.getString("u", null) == user && prefs.getString("p", null) == pass) return
            prefs.edit().putString("u", user).putString("p", pass).apply()
            runOnUiThread { Toast.makeText(this@MainActivity, "Login saved", Toast.LENGTH_SHORT).show() }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun newWeb(url: String) = WebView(this).apply {
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.allowFileAccess = false
        addJavascriptInterface(Bridge(), "AndroidBridge")
        webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, u: String) {
                view.evaluateJavascript(buildScript(), null)
            }
        }
        loadUrl(url)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Globe Rain The 101"

        routerWeb = newWeb(routerUrl)
        dashWeb = newWeb(dashboardUrl)

        val tabRouter = Button(this).apply { text = "Router" }
        val tabDash = Button(this).apply { text = "Dashboard" }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(tabRouter, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(tabDash, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        val content = FrameLayout(this).apply {
            addView(routerWeb, FrameLayout.LayoutParams(-1, -1))
            addView(dashWeb, FrameLayout.LayoutParams(-1, -1))
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(bar, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
            addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        }
        setContentView(root)

        fun select(dash: Boolean) {
            onDash = dash
            routerWeb.visibility = if (dash) View.GONE else View.VISIBLE
            dashWeb.visibility = if (dash) View.VISIBLE else View.GONE
            tabRouter.alpha = if (dash) 0.5f else 1f
            tabDash.alpha = if (dash) 1f else 0.5f
        }
        tabRouter.setOnClickListener { select(false) }
        tabDash.setOnClickListener { select(true) }
        select(false)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (web.canGoBack()) web.goBack() else finish()
            }
        })
    }

    // Autofills saved login and captures a new one when you submit the form
    private fun buildScript(): String {
        val u = JSONObject.quote(prefs.getString("u", "") ?: "")
        val p = JSONObject.quote(prefs.getString("p", "") ?: "")
        val auto = prefs.getBoolean("auto", true)
        return """
        (function(){
          if (window.__grInit) return; window.__grInit = true;
          var savedU = $u, savedP = $p, autoLogin = $auto;
          function fields(){
            var pw = document.querySelector('input[type=password]');
            if (!pw) return null;
            var all = Array.prototype.slice.call(document.querySelectorAll('input'));
            var user = null;
            for (var i = all.indexOf(pw) - 1; i >= 0; i--) {
              var t = (all[i].type || 'text').toLowerCase();
              if (t === 'text' || t === 'email' || t === 'tel') { user = all[i]; break; }
            }
            return {user: user, pw: pw};
          }
          function setVal(el, v){
            var s = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
            s.call(el, v);
            el.dispatchEvent(new Event('input', {bubbles:true}));
            el.dispatchEvent(new Event('change', {bubbles:true}));
          }
          function fill(){
            var f = fields();
            if (!f || !savedP) return;
            if (f.user && savedU) setVal(f.user, savedU);
            setVal(f.pw, savedP);
          }
          function capture(){
            var f = fields();
            if (f && f.pw.value) AndroidBridge.save(f.user ? f.user.value : '', f.pw.value);
          }
          function submitLogin(){
            if (!autoLogin || !savedP) return;
            if (sessionStorage.getItem('grAuto')) return; // only once, avoids loops on wrong password
            var f = fields();
            if (!f || f.pw.value !== savedP) return;
            sessionStorage.setItem('grAuto', '1');
            var form = f.pw.form || document;
            var btn = form.querySelector('button[type=submit], input[type=submit]');
            if (!btn) {
              var c = Array.prototype.slice.call(document.querySelectorAll('button, input[type=button], a'));
              btn = c.filter(function(b){ return /log\s*in|sign\s*in|submit|^ok$/i.test((b.innerText || b.value || '').trim()); })[0];
            }
            if (btn) btn.click(); else if (f.pw.form) f.pw.form.submit();
          }
          fill(); setTimeout(fill, 500); setTimeout(fill, 1500);
          setTimeout(submitLogin, 1800);
          document.addEventListener('click', function(e){
            var el = e.target.closest('button, input[type=submit], input[type=button], a');
            if (el) capture();
          }, true);
          document.addEventListener('keydown', function(e){ if (e.key === 'Enter') capture(); }, true);
          document.addEventListener('submit', capture, true);
        })();
        """.trimIndent()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menu.add(0, 1, 0, "Reload")
        menu.add(0, 2, 1, "Forget saved login")
        menu.add(0, 3, 2, "Auto login: " + if (prefs.getBoolean("auto", true)) "ON" else "OFF")
        return true
    }

    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        menu.findItem(3)?.title = "Auto login: " + if (prefs.getBoolean("auto", true)) "ON" else "OFF"
        return super.onPrepareOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            1 -> web.loadUrl(if (onDash) dashboardUrl else routerUrl)
            3 -> {
                prefs.edit().putBoolean("auto", !prefs.getBoolean("auto", true)).apply()
                routerWeb.loadUrl(routerUrl); dashWeb.loadUrl(dashboardUrl)
            }
            2 -> {
                prefs.edit().clear().apply()
                Toast.makeText(this, "Saved login removed", Toast.LENGTH_SHORT).show()
                routerWeb.loadUrl(routerUrl); dashWeb.loadUrl(dashboardUrl)
            }
        }
        return true
    }
}
