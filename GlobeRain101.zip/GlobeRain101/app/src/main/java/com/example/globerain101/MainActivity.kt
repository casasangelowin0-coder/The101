package com.example.globerain101

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    private val routerUrl = "http://192.168.0.1"
    private val dashboardUrl = "http://192.168.0.1/dashboard/"
    private val desktopUA =
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    private var defaultUA = ""

    private lateinit var routerWeb: WebView
    private lateinit var dashWeb: WebView
    private var onDash = false
    private val web: WebView get() = if (onDash) dashWeb else routerWeb

    private val prefs by lazy {
        val key = MasterKey.Builder(this).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(
            this, "router_login", key,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    inner class Bridge {
        @JavascriptInterface
        fun save(user: String, pass: String) {
            if (pass.isBlank()) return
            if (prefs.getString("u", null) == user && prefs.getString("p", null) == pass) return
            prefs.edit().putString("u", user).putString("p", pass).apply()
            toast("Login saved")
        }

        @JavascriptInterface
        fun toast(msg: String) {
            runOnUiThread { Toast.makeText(this@MainActivity, msg, Toast.LENGTH_SHORT).show() }
        }
    }

    private fun applyDesktop(w: WebView) {
        val d = prefs.getBoolean("desktop", false)
        w.settings.userAgentString = if (d) desktopUA else defaultUA
        w.settings.useWideViewPort = d
        w.settings.loadWithOverviewMode = d
        w.settings.setSupportZoom(true)
        w.settings.builtInZoomControls = true
        w.settings.displayZoomControls = false
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun newWeb(url: String) = WebView(this).apply {
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.allowFileAccess = false
        addJavascriptInterface(Bridge(), "AndroidBridge")
        applyDesktop(this)
        webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, u: String) {
                view.evaluateJavascript(buildScript(), null)
            }
        }
        loadUrl(url)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Globe Rain The 101"
        defaultUA = WebSettings.getDefaultUserAgent(this)

        routerWeb = newWeb(routerUrl)
        dashWeb = newWeb(dashboardUrl)

        val tabRouter = Button(this).apply { text = "Router" }
        val tabDash = Button(this).apply { text = "Dashboard" }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(tabRouter, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(tabDash, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        val content = FrameLayout(this).apply {
            addView(routerWeb, FrameLayout.LayoutParams(-1, -1))
            addView(dashWeb, FrameLayout.LayoutParams(-1, -1))
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(bar, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
            addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        }
        setContentView(root)

        fun select(dash: Boolean) {
            onDash = dash
            routerWeb.visibility = if (dash) View.GONE else View.VISIBLE
            dashWeb.visibility = if (dash) View.VISIBLE else View.GONE
            tabRouter.alpha = if (dash) 0.5f else 1f
            tabDash.alpha = if (dash) 1f else 0.5f
        }
        tabRouter.setOnClickListener { select(false) }
        tabDash.setOnClickListener { select(true) }
        select(false)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (web.canGoBack()) web.goBack() else finish()
            }
        })
    }

    private fun buildScript(): String {
        val u = JSONObject.quote(prefs.getString("u", "") ?: "")
        val p = JSONObject.quote(prefs.getString("p", "") ?: "")
        val auto = prefs.getBoolean("auto", true)
        val desktop = prefs.getBoolean("desktop", false)
        return """
        (function(){
          if (window.__grInit) return; window.__grInit = true;
          var savedU = $u, savedP = $p, autoLogin = $auto, desktop = $desktop;

          if (desktop) {
            var m = document.querySelector('meta[name=viewport]');
            if (!m) { m = document.createElement('meta'); m.name = 'viewport'; document.head.appendChild(m); }
            m.content = 'width=1280';
          }

          function fields(){
            var pw = document.querySelector('input[type=password]');
            if (!pw) return null;
            var all = Array.prototype.slice.call(document.querySelectorAll('input'));
            var user = null;
            for (var i = all.indexOf(pw) - 1; i >= 0; i--) {
              var t = (all[i].type || 'text').toLowerCase();
              if (t === 'text' || t === 'email' || t === 'tel') { user = all[i]; break; }
            }
            return {user: user, pw: pw};
          }
          function setVal(el, v){
            el.focus();
            var s = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
            s.call(el, v);
            ['keydown','keypress','input','keyup','change'].forEach(function(n){
              el.dispatchEvent(new Event(n, {bubbles:true}));
            });
            el.blur();
          }

          // ---- capture login ----
          var last = {u:'', p:''};
          function remember(){
            var f = fields();
            if (f && f.pw.value) { last.u = f.user ? f.user.value : ''; last.p = f.pw.value; }
          }
          function push(){ remember(); if (last.p) AndroidBridge.save(last.u, last.p); }
          document.addEventListener('input', remember, true);
          document.addEventListener('change', remember, true);
          document.addEventListener('click', function(e){
            if (e.target.closest && e.target.closest('button, input[type=submit], input[type=button], a, [role=button]')) push();
          }, true);
          document.addEventListener('keydown', function(e){ if (e.key === 'Enter') push(); }, true);
          document.addEventListener('submit', push, true);
          window.addEventListener('pagehide', push);
          window.addEventListener('beforeunload', push);

          // ---- auto login ----
          function submitLogin(){
            var t = parseInt(sessionStorage.getItem('grAutoT') || '0');
            if (Date.now() - t < 20000) return;   // avoid loops on wrong password
            sessionStorage.setItem('grAutoT', String(Date.now()));
            var f = fields(); if (!f) return;
            var scope = f.pw.form || document;
            var btn = scope.querySelector('button[type=submit], input[type=submit]');
            if (!btn) {
              var c = Array.prototype.slice.call(document.querySelectorAll('button, input[type=button], input[type=submit], a, [role=button], .btn'));
              btn = c.filter(function(b){
                return /log\s*in|sign\s*in|submit|continue|^ok${'$'}/i.test((b.innerText || b.value || '').trim());
              })[0];
            }
            AndroidBridge.toast('Auto login...');
            if (btn) btn.click();
            else {
              f.pw.dispatchEvent(new KeyboardEvent('keydown', {key:'Enter', keyCode:13, which:13, bubbles:true}));
              if (f.pw.form) { if (f.pw.form.requestSubmit) f.pw.form.requestSubmit(); else f.pw.form.submit(); }
            }
          }
          var tries = 0;
          var timer = setInterval(function(){
            if (++tries > 40) { clearInterval(timer); return; }   // waits up to ~20s for the form
            var f = fields();
            if (!f || !savedP) return;
            clearInterval(timer);
            if (f.pw.value !== savedP) {
              if (f.user && savedU) setVal(f.user, savedU);
              setVal(f.pw, savedP);
            }
            if (autoLogin) setTimeout(submitLogin, 700);
          }, 500);
        })();
        """.trimIndent()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menu.add(0, 1, 0, "Reload")
        menu.add(0, 2, 1, "Forget saved login")
        menu.add(0, 3, 2, "")
        menu.add(0, 4, 3, "")
        return true
    }

    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        menu.findItem(3)?.title = "Auto login: " + if (prefs.getBoolean("auto", true)) "ON" else "OFF"
        menu.findItem(4)?.title = "Desktop mode: " + if (prefs.getBoolean("desktop", false)) "ON" else "OFF"
        return super.onPrepareOptionsMenu(menu)
    }

    private fun reloadBoth() {
        routerWeb.loadUrl(routerUrl); dashWeb.loadUrl(dashboardUrl)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            1 -> web.loadUrl(if (onDash) dashboardUrl else routerUrl)
            2 -> {
                val auto = prefs.getBoolean("auto", true)
                val desk = prefs.getBoolean("desktop", false)
                prefs.edit().clear().putBoolean("auto", auto).putBoolean("desktop", desk).apply()
                Toast.makeText(this, "Saved login removed", Toast.LENGTH_SHORT).show()
                reloadBoth()
            }
            3 -> {
                prefs.edit().putBoolean("auto", !prefs.getBoolean("auto", true)).apply()
                reloadBoth()
            }
            4 -> {
                prefs.edit().putBoolean("desktop", !prefs.getBoolean("desktop", false)).apply()
                applyDesktop(routerWeb); applyDesktop(dashWeb)
                reloadBoth()
            }
        }
        return true
    }
}
