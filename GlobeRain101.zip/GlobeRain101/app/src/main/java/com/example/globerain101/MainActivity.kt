package com.example.globerain101

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.text.InputType
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import androidx.appcompat.app.AlertDialog
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    private val routerUrl = "http://192.168.0.1"
    private val dashboardUrl = "http://192.168.0.1/dashboard/"
    private val desktopUA =
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    private var defaultUA = ""

    private lateinit var routerWeb: WebView
    private lateinit var dashWeb: WebView
    private var onDash = false
    private val web: WebView get() = if (onDash) dashWeb else routerWeb

    private val prefs by lazy {
        val key = MasterKey.Builder(this).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(
            this, "router_login", key,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    inner class Bridge {
        @JavascriptInterface
        fun toast(msg: String) {
            runOnUiThread { Toast.makeText(this@MainActivity, msg, Toast.LENGTH_SHORT).show() }
        }
    }

    private fun applyDesktop(w: WebView) {
        val d = prefs.getBoolean("desktop", false)
        w.settings.userAgentString = if (d) desktopUA else defaultUA
        w.settings.useWideViewPort = d
        w.settings.loadWithOverviewMode = false      // overview mode caused the re-zoom on taps
        w.settings.setSupportZoom(true)
        w.settings.builtInZoomControls = true
        w.settings.displayZoomControls = false
        w.settings.textZoom = 100
        if (d) {
            val dm = resources.displayMetrics
            val fit = (dm.widthPixels / dm.density / 1280f * 100f).toInt().coerceAtLeast(20)
            w.setInitialScale(fit)                   // fixed starting zoom, set once
        } else {
            w.setInitialScale(0)
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun newWeb(url: String) = WebView(this).apply {
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.allowFileAccess = false
        addJavascriptInterface(Bridge(), "AndroidBridge")
        applyDesktop(this)
        webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, u: String) {
                view.evaluateJavascript(buildScript(), null)
            }
        }
        loadUrl(url)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Globe Rain The 101"
        defaultUA = WebSettings.getDefaultUserAgent(this)

        routerWeb = newWeb(routerUrl)
        dashWeb = newWeb(dashboardUrl)

        val tabRouter = Button(this).apply { text = "Router" }
        val tabDash = Button(this).apply { text = "Dashboard" }
        val credBtn = Button(this).apply { text = "Credentials" }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(tabRouter, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(tabDash, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(credBtn, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        val content = FrameLayout(this).apply {
            addView(routerWeb, FrameLayout.LayoutParams(-1, -1))
            addView(dashWeb, FrameLayout.LayoutParams(-1, -1))
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(bar, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
            addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        }
        setContentView(root)

        fun select(dash: Boolean) {
            onDash = dash
            routerWeb.visibility = if (dash) View.GONE else View.VISIBLE
            dashWeb.visibility = if (dash) View.VISIBLE else View.GONE
            tabRouter.alpha = if (dash) 0.5f else 1f
            tabDash.alpha = if (dash) 1f else 0.5f
        }
        tabRouter.setOnClickListener { select(false) }
        tabDash.setOnClickListener { select(true) }
        select(false)
        credBtn.setOnClickListener { showCredentials() }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (web.canGoBack()) web.goBack() else finish()
            }
        })
    }

    // Runs on every page load: only sets the desktop viewport. Nothing is captured from pages.
    private fun buildScript(): String {
        if (!prefs.getBoolean("desktop", false)) return "void 0;"
        return """
        (function(){
          var m = document.querySelector('meta[name=viewport]');
          if (!m) { m = document.createElement('meta'); m.name = 'viewport'; document.head.appendChild(m); }
          m.content = 'width=1280';
        })();
        """.trimIndent()
    }

    // Fills the login form with your saved credentials by "typing" them key by key,
    // so pages that validate on keyup/input (Vue, Angular, jQuery...) accept the values.
    private fun fillScript(): String {
        val u = JSONObject.quote(prefs.getString("u", "") ?: "")
        val p = JSONObject.quote(prefs.getString("p", "") ?: "")
        return """
        (function(){
          var savedU = $u, savedP = $p;
          if (!savedP && !savedU) { AndroidBridge.toast('No credentials saved - tap Credentials first'); return; }

          function collect(root, out){
            try {
              root.querySelectorAll('input').forEach(function(i){ out.push(i); });
              root.querySelectorAll('*').forEach(function(n){ if (n.shadowRoot) collect(n.shadowRoot, out); });
              root.querySelectorAll('iframe').forEach(function(fr){
                try { if (fr.contentDocument) collect(fr.contentDocument, out); } catch(e) {}
              });
            } catch(e) {}
          }
          function vis(el){ return el.offsetParent !== null || el.getClientRects().length > 0; }
          function hint(el){ return ((el.name||'') + ' ' + (el.id||'') + ' ' + (el.placeholder||'') + ' ' + (el.autocomplete||'') + ' ' + (el.getAttribute('aria-label')||'')).toLowerCase(); }

          var inputs = []; collect(document, inputs);
          var shown = inputs.filter(vis);
          var pw = shown.filter(function(i){ return (i.type||'').toLowerCase() === 'password'; })[0]
                || shown.filter(function(i){ return /pass|pwd/.test(hint(i)); })[0];
          if (!pw) { AndroidBridge.toast('No password box found on this page'); return; }

          var user = null, idx = shown.indexOf(pw);
          for (var i = idx - 1; i >= 0; i--) {
            var t = (shown[i].type || 'text').toLowerCase();
            if (t === 'text' || t === 'email' || t === 'tel') { user = shown[i]; break; }
          }

          function typeInto(el, v){
            var setter = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(el), 'value').set;
            el.focus();
            setter.call(el, '');
            el.dispatchEvent(new Event('input', {bubbles:true}));
            for (var i = 0; i < v.length; i++) {
              var ch = v.charAt(i), code = v.charCodeAt(i);
              var kd = {key: ch, keyCode: code, which: code, charCode: code, bubbles: true, cancelable: true};
              el.dispatchEvent(new KeyboardEvent('keydown', kd));
              el.dispatchEvent(new KeyboardEvent('keypress', kd));
              setter.call(el, el.value + ch);
              el.dispatchEvent(new InputEvent('input', {bubbles: true, data: ch, inputType: 'insertText'}));
              el.dispatchEvent(new KeyboardEvent('keyup', kd));
            }
            el.dispatchEvent(new Event('change', {bubbles: true}));
            el.blur();
          }

          if (user && savedU) typeInto(user, savedU);
          if (savedP) typeInto(pw, savedP);

          setTimeout(function(){
            var okP = !savedP || pw.value === savedP;
            var okU = !user || !savedU || user.value === savedU;
            AndroidBridge.toast(okP && okU ? 'Login filled' : 'The page cleared the ' + (okP ? 'username' : 'password') + ' - tap Credentials and try again');
          }, 300);
        })();
        """.trimIndent()
    }

    private fun showCredentials() {
        val pad = (20 * resources.displayMetrics.density).toInt()
        val user = EditText(this).apply {
            hint = "Username"
            inputType = InputType.TYPE_CLASS_TEXT
            setText(prefs.getString("u", ""))
        }
        val pass = EditText(this).apply {
            hint = "Password"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(prefs.getString("p", ""))
        }
        val show = CheckBox(this).apply {
            text = "Show password"
            setOnCheckedChangeListener { _, on ->
                pass.inputType = InputType.TYPE_CLASS_TEXT or
                    if (on) InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD else InputType.TYPE_TEXT_VARIATION_PASSWORD
                pass.setSelection(pass.text.length)
            }
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad / 2, pad, 0)
            addView(user); addView(pass); addView(show)
        }
        fun save() {
            prefs.edit().putString("u", user.text.toString().trim()).putString("p", pass.text.toString()).apply()
        }
        AlertDialog.Builder(this)
            .setTitle("Login credentials")
            .setView(box)
            .setPositiveButton("Save & fill") { _, _ ->
                save()
                web.evaluateJavascript(fillScript(), null)
            }
            .setNeutralButton("Save") { _, _ ->
                save()
                Toast.makeText(this, "Credentials saved", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menu.add(0, 1, 0, "Reload")
        menu.add(0, 2, 1, "Forget saved login")
        menu.add(0, 4, 3, "")
        return true
    }

    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        menu.findItem(4)?.title = "Desktop mode: " + if (prefs.getBoolean("desktop", false)) "ON" else "OFF"
        return super.onPrepareOptionsMenu(menu)
    }

    private fun reloadBoth() {
        routerWeb.loadUrl(routerUrl); dashWeb.loadUrl(dashboardUrl)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            1 -> web.loadUrl(if (onDash) dashboardUrl else routerUrl)
            2 -> {
                val desk = prefs.getBoolean("desktop", false)
                prefs.edit().clear().putBoolean("desktop", desk).apply()
                Toast.makeText(this, "Saved login removed", Toast.LENGTH_SHORT).show()
                reloadBoth()
            }
            4 -> {
                prefs.edit().putBoolean("desktop", !prefs.getBoolean("desktop", false)).apply()
                applyDesktop(routerWeb); applyDesktop(dashWeb)
                reloadBoth()
            }
        }
        return true
    }
}
